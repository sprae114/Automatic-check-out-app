package com.example.new_myipaddress;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.text.format.Formatter;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

public class MenuActivity extends AppCompatActivity {

    int counter = 0;
    int click = 0;

    private static final long START_TIME_IN_MILLIS=3000;//원래는 600000였음.테스트할라고 줄인거
    private static final long START_TIME_IN_MILLIS2=3000;

    private TextView mTextViewCountDown;
    private TextView mTextViewCountDown2;

    private Button mButtonStart;
    private Button mButtonStart2;

    private Button mButtonReset;
    private Button mButtonReset2;

    private CountDownTimer mCountDownTimer;
    private CountDownTimer mCountDownTimer2;

    private boolean mTimerRunning;
    private boolean mTimerRunning2;

    private long mTimeLeftInMillis = START_TIME_IN_MILLIS;
    private long mTimeLeftInMillis2 = START_TIME_IN_MILLIS2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        final String ipAddress = Formatter.formatIpAddress(wifiManager.getConnectionInfo().getIpAddress());
        //final String library_wifi = "192.168.232.2";
        final String library_wifi = "192.168.0.4";

        TimerTask tt;
        tt = new TimerTask() {
            @Override
            public void run() {
                if (library_wifi.equals(ipAddress)) {
                    Log.i("","와이파이 동일");
                }

                if (!library_wifi.equals(ipAddress)) {
                    if (counter<3 && click<2){
                        Log.i("","휴식시간 or 점심시간");
                    }

                    if (counter>2 && click>1){
                        Toast.makeText(MenuActivity.this, "자동퇴실 되었습니다..", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                    }

                }

            }
        };

        Timer timer = new Timer();
        timer.schedule(tt, 0, 60000);


        Button button_seat = (Button) findViewById(R.id.button_seat);
        button_seat.setBackgroundColor(Color.WHITE);
        button_seat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), SeatsActivity.class);
                startActivity(intent);
            }
        });
        //좌석버튼 코딩


        mTextViewCountDown = findViewById(R.id.text_view_countdown);
        mTextViewCountDown2 = findViewById(R.id.text_view_countdown2);

        mButtonStart = findViewById(R.id.button_start);
        mButtonStart.setBackgroundColor(Color.WHITE);
        mButtonStart2 = findViewById(R.id.button_start2);
        mButtonStart2.setBackgroundColor(Color.WHITE);

        mButtonReset = findViewById(R.id.button_reset);

        mButtonReset2 = findViewById(R.id.button_reset2);


        final TextView textView1 = (TextView) findViewById(R.id.textView1);
        final TextView textView2 = (TextView) findViewById(R.id.textView2);
        final TextView seat_text = (TextView)findViewById(R.id.seat_text);

        Intent intent = getIntent();
        String seat_number = intent.getStringExtra("seat");
        seat_text.setText(seat_number);
        //좌석 알려주는 코드

        mButtonStart.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                if(counter==0){
                    textView1.setText("휴식은 총 3회 주어짐");
                    counter++;
                }
                else if(counter==1){
                    textView1.setText("휴식 1회 사용함");
                    startTimer();
                    counter++;
                    if (!library_wifi.equals(ipAddress)){
                        Handler delayHandler = new Handler();
                        delayHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MenuActivity.this, "자동퇴실 되었습니다..", Toast.LENGTH_SHORT).show();
                                finishAffinity();
                                System.runFinalization();
                                System.exit(0);
                            }
                        }, 3000);//딜레이 3초
                    }
                }
                else if(counter==2){
                    textView1.setText("휴식 2회 사용함");
                    startTimer();
                    counter++;
                    if (!library_wifi.equals(ipAddress)){
                        Handler delayHandler = new Handler();
                        delayHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MenuActivity.this, "자동퇴실 되었습니다..", Toast.LENGTH_SHORT).show();
                                finishAffinity();
                                System.runFinalization();
                                System.exit(0);
                            }
                        }, 3000);//딜레이 3초
                    }
                }
                else if(counter==3){
                    textView1.setText("휴식 3회 사용함");
                    startTimer();
                    counter++;
                    if (!library_wifi.equals(ipAddress)){
                        Handler delayHandler = new Handler();
                        delayHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MenuActivity.this, "자동퇴실 되었습니다..", Toast.LENGTH_SHORT).show();
                                finishAffinity();
                                System.runFinalization();
                                System.exit(0);
                            }
                        }, 3000);//딜레이 3초
                    }
                }
                else{
                    mButtonStart.setEnabled(false);
                }

            }
        });
        updateCountDownText();

        mButtonStart2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                if(click==0){
                    textView2.setText("식사는 총 2회 주어짐");
                    click++;
                }
                else if(click==1){
                    textView2.setText("식사 1회 사용함");
                    startTimer2();
                    click++;
                    if (!library_wifi.equals(ipAddress)){
                        Handler delayHandler = new Handler();
                        delayHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MenuActivity.this, "자동퇴실 되었습니다..", Toast.LENGTH_SHORT).show();
                                finishAffinity();
                                System.runFinalization();
                                System.exit(0);
                            }
                        }, 3000);//딜레이 3초
                    }
                }
                else if(click==2){
                    textView2.setText("식사 2회 사용함");
                    startTimer2();
                    click++;
                    if (!library_wifi.equals(ipAddress)){
                        Handler delayHandler = new Handler();
                        delayHandler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MenuActivity.this, "자동퇴실 되었습니다..", Toast.LENGTH_SHORT).show();
                                finishAffinity();
                                System.runFinalization();
                                System.exit(0);
                            }
                        }, 3000);//딜레이 3초
                    }
                }
                else{
                    mButtonStart2.setEnabled(false);
                }

            }
        });
        updateCountDownText2();

        mButtonReset.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                resetTimer();
            }
        });
        updateCountDownText();


        mButtonReset2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                resetTimer2();
            }
        });
        updateCountDownText2();
    }

    private void startTimer(){
        mCountDownTimer = new CountDownTimer(mTimeLeftInMillis,1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                mTimeLeftInMillis = millisUntilFinished;
                updateCountDownText();
            }

            @Override
            public void onFinish() {
                mTimerRunning = false;
                mButtonStart.setText("휴식");
                mButtonStart.setVisibility(View.VISIBLE);
                mButtonReset.setVisibility(View.VISIBLE);
            }
        }.start();
        mTimerRunning = true;
        mButtonReset.setVisibility(View.VISIBLE);
    }

    private void startTimer2(){
        mCountDownTimer2 = new CountDownTimer(mTimeLeftInMillis2,1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                mTimeLeftInMillis2 = millisUntilFinished;
                updateCountDownText2();
            }

            @Override
            public void onFinish() {
                mTimerRunning2 = false;
                mButtonStart2.setText("식사");
                mButtonStart2.setVisibility(View.VISIBLE);
                mButtonReset2.setVisibility(View.VISIBLE);
            }
        }.start();
        mTimerRunning2 = true;
        mButtonReset2.setVisibility(View.VISIBLE);
    }


    private void resetTimer(){
        mTimeLeftInMillis=START_TIME_IN_MILLIS;
        updateCountDownText();
        mButtonReset.setVisibility(View.VISIBLE);
        mButtonStart.setVisibility(View.VISIBLE);
    }

    private void resetTimer2(){
        mTimeLeftInMillis2=START_TIME_IN_MILLIS2;
        updateCountDownText2();
        mButtonReset2.setVisibility(View.VISIBLE);
        mButtonStart2.setVisibility(View.VISIBLE);
    }

    private void updateCountDownText(){
        int minutes = (int)(mTimeLeftInMillis/1000)/60;
        int seconds = (int)(mTimeLeftInMillis/1000)%60;

        String timeLeftFormatted = String.format(Locale.getDefault(),"%02d:%02d",minutes,seconds);
        mTextViewCountDown.setText(timeLeftFormatted);
    }


    private void updateCountDownText2(){
        int minutes = (int)(mTimeLeftInMillis2/1000)/60;
        int seconds = (int)(mTimeLeftInMillis2/1000)%60;

        String timeLeftFormatted2 = String.format(Locale.getDefault(),"%02d:%02d",minutes,seconds);
        mTextViewCountDown2.setText(timeLeftFormatted2);
    }



}


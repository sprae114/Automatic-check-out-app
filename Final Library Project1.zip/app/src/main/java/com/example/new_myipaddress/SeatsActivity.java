package com.example.new_myipaddress;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.text.format.Formatter;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;

import java.util.Timer;
import java.util.TimerTask;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class SeatsActivity extends AppCompatActivity {

    ScrollView scrollView;
@Override
protected void onSaveInstanceState(Bundle outState) {

    super.onSaveInstanceState(outState);
}
    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_seats);
        final Intent intent = getIntent();


        scrollView = (ScrollView) findViewById(R.id.scrollView);
        scrollView.setHorizontalScrollBarEnabled(true);


        final Button button_a1 = (Button) findViewById(R.id.button_a1);
        button_a1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a1.setText("사용");
                                button_a1.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A1 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();
            }
        });


        final Button button_a2 = (Button) findViewById(R.id.button_a2);
        button_a2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a2.setText("사용");
                                button_a2.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A2 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_a3 = (Button) findViewById(R.id.button_a3);
        button_a3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a3.setText("사용");
                                button_a3.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A3 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_a4 = (Button) findViewById(R.id.button_a4);
        button_a4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a4.setText("사용");
                                button_a4.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A4 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_a5 = (Button) findViewById(R.id.button_a5);
        button_a5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a5.setText("사용");
                                button_a5.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A5 입니다.");
                                startActivity(intent);
                            }


                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_a6 = (Button) findViewById(R.id.button_a6);
        button_a6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a6.setText("사용");
                                button_a6.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A6 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_a7 = (Button) findViewById(R.id.button_a7);
        button_a7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a7.setText("사용");
                                button_a7.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A7 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_a8 = (Button) findViewById(R.id.button_a8);
        button_a8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a8.setText("사용");
                                button_a8.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A8 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_a9 = (Button) findViewById(R.id.button_a9);
        button_a9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a9.setText("사용");
                                button_a9.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A9 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_a10 = (Button) findViewById(R.id.button_a10);
        button_a10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a10.setText("사용");
                                button_a10.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A10 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });

        final Button button_a11 = (Button) findViewById(R.id.button_a11);
        button_a11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a11.setText("사용");
                                button_a11.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A11 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_a12 = (Button) findViewById(R.id.button_a12);
        button_a12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a12.setText("사용");
                                button_a12.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A12 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_a13 = (Button) findViewById(R.id.button_a13);
        button_a13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a13.setText("사용");
                                button_a13.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A13 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_a14 = (Button) findViewById(R.id.button_a14);
        button_a14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a14.setText("사용");
                                button_a14.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A14 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_a15 = (Button) findViewById(R.id.button_a15);
        button_a15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a15.setText("사용");
                                button_a15.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A15 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_a16 = (Button) findViewById(R.id.button_a16);
        button_a16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a16.setText("사용");
                                button_a16.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A16 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_a17 = (Button) findViewById(R.id.button_a17);
        button_a17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a17.setText("사용");
                                button_a17.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A17 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_a18 = (Button) findViewById(R.id.button_a18);
        button_a18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a18.setText("사용");
                                button_a18.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A18 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_a19 = (Button) findViewById(R.id.button_a19);
        button_a19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a19.setText("사용");
                                button_a19.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A19 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_a20 = (Button) findViewById(R.id.button_a20);
        button_a20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a20.setText("사용");
                                button_a20.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A20 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_a21 = (Button) findViewById(R.id.button_a21);
        button_a21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a21.setText("사용");
                                button_a21.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A21 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });

        final Button button_a22 = (Button) findViewById(R.id.button_a22);
        button_a22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a22.setText("사용");
                                button_a22.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A22 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_a23 = (Button) findViewById(R.id.button_a23);
        button_a23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a23.setText("사용");
                                button_a23.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A23 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_a24 = (Button) findViewById(R.id.button_a24);
        button_a24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_a24.setText("사용");
                                button_a24.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 A24 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_b1 = (Button) findViewById(R.id.button_b1);
        button_b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b1.setText("사용");
                                button_b1.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B1 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();
            }
        });


        final Button button_b2 = (Button) findViewById(R.id.button_b2);
        button_b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b2.setText("사용");
                                button_b2.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B2 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_b3 = (Button) findViewById(R.id.button_b3);
        button_b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b3.setText("사용");
                                button_b3.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B3 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_b4 = (Button) findViewById(R.id.button_b4);
        button_a4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b4.setText("사용");
                                button_b4.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B4 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_b5 = (Button) findViewById(R.id.button_b5);
        button_b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b5.setText("사용");
                                button_b5.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B5 입니다.");
                                startActivity(intent);
                            }


                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_b6 = (Button) findViewById(R.id.button_b6);
        button_b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b6.setText("사용");
                                button_b6.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B6 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_b7 = (Button) findViewById(R.id.button_b7);
        button_b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b7.setText("사용");
                                button_b7.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B7 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_b8 = (Button) findViewById(R.id.button_b8);
        button_b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b8.setText("사용");
                                button_b8.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B8 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_b9 = (Button) findViewById(R.id.button_b9);
        button_b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b9.setText("사용");
                                button_b9.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B9 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_b10 = (Button) findViewById(R.id.button_b10);
        button_b10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b10.setText("사용");
                                button_b10.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B10 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });

        final Button button_b11 = (Button) findViewById(R.id.button_b11);
        button_b11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b11.setText("사용");
                                button_b11.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B11 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_b12 = (Button) findViewById(R.id.button_b12);
        button_b12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b12.setText("사용");
                                button_b12.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B12 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_b13 = (Button) findViewById(R.id.button_b13);
        button_b13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b13.setText("사용");
                                button_b13.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B13 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_b14 = (Button) findViewById(R.id.button_b14);
        button_b14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b14.setText("사용");
                                button_b14.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B14 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_b15 = (Button) findViewById(R.id.button_b15);
        button_b15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b15.setText("사용");
                                button_b15.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B15 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_b16 = (Button) findViewById(R.id.button_b16);
        button_b16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b16.setText("사용");
                                button_b16.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B16 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_b17 = (Button) findViewById(R.id.button_b17);
        button_b17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b17.setText("사용");
                                button_b17.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B17 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_b18 = (Button) findViewById(R.id.button_b18);
        button_b18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b18.setText("사용");
                                button_b18.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B18 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_b19 = (Button) findViewById(R.id.button_b19);
        button_b19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b19.setText("사용");
                                button_b19.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B19 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_b20 = (Button) findViewById(R.id.button_b20);
        button_b20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b20.setText("사용");
                                button_b20.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B20 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_b21 = (Button) findViewById(R.id.button_b21);
        button_b21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b21.setText("사용");
                                button_b21.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B21 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });

        final Button button_b22 = (Button) findViewById(R.id.button_b22);
        button_b22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b22.setText("사용");
                                button_b22.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B22 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_b23 = (Button) findViewById(R.id.button_b23);
        button_b23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b23.setText("사용");
                                button_b23.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B23 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_b24 = (Button) findViewById(R.id.button_b24);
        button_b24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_b24.setText("사용");
                                button_b24.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 B24 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_c1 = (Button) findViewById(R.id.button_c1);
        button_c1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c1.setText("사용");
                                button_c1.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C1 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();
            }
        });


        final Button button_c2 = (Button) findViewById(R.id.button_c2);
        button_c2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c2.setText("사용");
                                button_c2.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C2 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_c3 = (Button) findViewById(R.id.button_c3);
        button_c3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c3.setText("사용");
                                button_c3.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C3 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_c4 = (Button) findViewById(R.id.button_c4);
        button_c4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c4.setText("사용");
                                button_c4.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C4 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_c5 = (Button) findViewById(R.id.button_c5);
        button_c5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c5.setText("사용");
                                button_c5.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C5 입니다.");
                                startActivity(intent);
                            }


                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_c6 = (Button) findViewById(R.id.button_c6);
        button_c6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c6.setText("사용");
                                button_c6.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C6 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_c7 = (Button) findViewById(R.id.button_c7);
        button_c7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c7.setText("사용");
                                button_c7.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C7 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_c8 = (Button) findViewById(R.id.button_c8);
        button_c8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c8.setText("사용");
                                button_c8.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C8 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_c9 = (Button) findViewById(R.id.button_c9);
        button_c9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c9.setText("사용");
                                button_c9.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C9 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_c10 = (Button) findViewById(R.id.button_c10);
        button_c10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c10.setText("사용");
                                button_c10.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C10 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });

        final Button button_c11 = (Button) findViewById(R.id.button_c11);
        button_c11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c11.setText("사용");
                                button_c11.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C11 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_c12 = (Button) findViewById(R.id.button_c12);
        button_c12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c12.setText("사용");
                                button_c12.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C12 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_c13 = (Button) findViewById(R.id.button_c13);
        button_c13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c13.setText("사용");
                                button_c13.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C13 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_c14 = (Button) findViewById(R.id.button_c14);
        button_c14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c14.setText("사용");
                                button_c14.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C14 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_c15 = (Button) findViewById(R.id.button_c15);
        button_c15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c15.setText("사용");
                                button_c15.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C15 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_c16 = (Button) findViewById(R.id.button_c16);
        button_c16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c16.setText("사용");
                                button_c16.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C16 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_c17 = (Button) findViewById(R.id.button_c17);
        button_c17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c17.setText("사용");
                                button_c17.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C17 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_c18 = (Button) findViewById(R.id.button_c18);
        button_c18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c18.setText("사용");
                                button_c18.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C18 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_c19 = (Button) findViewById(R.id.button_c19);
        button_c19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c19.setText("사용");
                                button_c19.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C19 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_c20 = (Button) findViewById(R.id.button_c20);
        button_c20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c20.setText("사용");
                                button_c20.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C20 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_c21 = (Button) findViewById(R.id.button_c21);
        button_c21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c21.setText("사용");
                                button_c21.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C21 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });

        final Button button_c22 = (Button) findViewById(R.id.button_c22);
        button_c22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c22.setText("사용");
                                button_c22.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C22 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_c23 = (Button) findViewById(R.id.button_c23);
        button_c23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c23.setText("사용");
                                button_c23.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C23 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });


        final Button button_c24 = (Button) findViewById(R.id.button_c24);
        button_c24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(SeatsActivity.this);
                builder.setMessage("이 좌석을 선택하시겠습니까?");
                builder.setTitle("좌석 선택").setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                button_c24.setText("사용");
                                button_c24.setBackgroundColor(Color.RED);
                                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                                intent.putExtra("seat","현재 이용중인 좌석은 C24 입니다.");
                                startActivity(intent);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.setTitle("좌석 선택");
                alert.show();

            }
        });

    }

}
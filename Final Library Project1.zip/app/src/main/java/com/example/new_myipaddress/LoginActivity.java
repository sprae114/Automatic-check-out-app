package com.example.new_myipaddress;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.media.AudioManager;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    private AudioManager audioManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button loginButton = (Button) findViewById(R.id.loginButton);
        loginButton.setBackgroundColor(Color.WHITE);
        audioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int mod = audioManager.getRingerMode();
                if (mod == audioManager.RINGER_MODE_SILENT) {
                    Intent intent = new Intent(getApplicationContext(), SeatsActivity.class);
                    startActivity(intent);
                }else if (mod == audioManager.RINGER_MODE_VIBRATE ) {
                    Toast.makeText(LoginActivity.this, "무음모드로 전환해주십시오", Toast.LENGTH_SHORT).show();
                }else if (mod == audioManager.RINGER_MODE_NORMAL ) {
                    Toast.makeText(LoginActivity.this, "무음모드로 전환해주십시오", Toast.LENGTH_SHORT).show();
                }
            }
        });}}
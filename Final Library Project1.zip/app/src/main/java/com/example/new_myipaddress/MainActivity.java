package com.example.new_myipaddress;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.net.wifi.WifiManager;
//import android.os.Bundle;
//import android.support.v7.app.AppCompatActivity;
import android.text.format.Formatter;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import static java.sql.DriverManager.println;


public class MainActivity extends AppCompatActivity {

    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView) findViewById(R.id.android_device_ip_address);
        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);

        final String ipAddress = Formatter.formatIpAddress(wifiManager.getConnectionInfo().getIpAddress());

        textView.setText("Your Device IP Address: " + ipAddress);

        //String library_wifi = "192.168.232.2";
        final String library_wifi = "192.168.0.4";
        //스마트폰에서 와이파이 연결시 앱 창에 뜨는 본인 와이파이 ip적으면 됩니당

        
        Button FirstButton = (Button)findViewById(R.id.FirstButton);
        FirstButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                if (library_wifi.equals(ipAddress)) {
                    Toast.makeText(MainActivity.this, "도서관 와이파이임이 확인됐습니다.", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(intent);
                }
                if (!library_wifi.equals(ipAddress)) {
                    Toast.makeText(MainActivity.this, "도서관 와이파이 연결을 확인해주세요.", Toast.LENGTH_SHORT).show();
                    finish();
                    //도서관 와이파이가 아닐시 앱 종료하게 만들었음.

        }
            }

    });

}
}
